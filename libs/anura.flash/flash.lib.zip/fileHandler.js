export function openFile(path) {
  let swfView = AliceWM.create("Flash Player");
  const iframe = document.createElement("iframe");
  iframe.setAttribute(
    "style",
    "top:0; left:0; bottom:0; right:0; width:100%; height:100%; border: none; margin: 0; padding: 0; background-color: #202124;"
  );
  const url =
    import.meta.url.substring(0, import.meta.url.lastIndexOf("/")) +
    "/index.html?path=" + path;
  iframe.setAttribute("src", url);
  swfView.content.appendChild(iframe);
}
