window.addEventListener('DOMContentLoaded', () => {
  let whereAmI = window.location.pathname.split('/')
  whereAmI.pop()

  anura.files.set(whereAmI.join('/') + '/fileHandler.js', 'swf')
});
// kill me
